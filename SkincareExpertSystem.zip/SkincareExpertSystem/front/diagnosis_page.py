import customtkinter as ctk

from front.theme import *
from back.knowledge import SYMPTOMS


class DiagnosisPage(ctk.CTkFrame):

    def __init__(self, parent, finish_callback):
        super().__init__(parent, fg_color=BACKGROUND)

        self.finish_callback = finish_callback

        self.symptoms = list(SYMPTOMS.items())
        self.current = 0
        self.answers = {}

        # ==========================
        # Header
        # ==========================

        title = ctk.CTkLabel(
            self,
            text="Diagnosis Kondisi Kulit",
            font=TITLE_FONT,
            text_color=PRIMARY
        )
        title.pack(pady=(20, 10))

        self.progress_label = ctk.CTkLabel(
            self,
            text="",
            font=HEADER_FONT
        )
        self.progress_label.pack()

        self.progress = ctk.CTkProgressBar(
            self,
            width=500
        )
        self.progress.pack(pady=(5, 20))

        # ==========================
        # Card
        # ==========================

        self.card = ctk.CTkFrame(
            self,
            corner_radius=15
        )

        self.card.pack(
            padx=40,
            pady=10,
            fill="both",
            expand=True
        )

        # ==========================
        # Pertanyaan
        # ==========================

        self.question = ctk.CTkLabel(
            self.card,
            text="",
            wraplength=700,
            justify="center",
            font=("Segoe UI", 22, "bold")
        )

        self.question.pack(pady=(30, 30))

        # ==========================
        # Jawaban
        # ==========================

        self.choice = ctk.StringVar(value="")

        self.radio_frame = ctk.CTkFrame(
            self.card,
            fg_color="transparent"
        )

        self.radio_frame.pack()

        options = [
            ("Tidak", "0.0"),
            ("Kurang Yakin", "0.2"),
            ("Sedikit Yakin", "0.4"),
            ("Cukup Yakin", "0.6"),
            ("Yakin", "0.8"),
            ("Sangat Yakin", "1.0"),
        ]

        for text, value in options:

            rb = ctk.CTkRadioButton(
                self.radio_frame,
                text=text,
                variable=self.choice,
                value=value
            )

            rb.pack(
                anchor="w",
                pady=5,
                padx=20
            )

        # ==========================
        # Next Button
        # ==========================

        self.next_button = ctk.CTkButton(
            self,
            text="Selanjutnya",
            width=200,
            height=45,
            font=BUTTON_FONT,
            command=self.next_question
        )

        self.next_button.pack(pady=20)

        self.load_question()

    def load_question(self):
        code, symptom = self.symptoms[self.current]

        self.progress_label.configure(
            text=f"Pertanyaan {self.current + 1} / {len(self.symptoms)}"
        )

        self.progress.set(
            (self.current + 1) / len(self.symptoms)
        )

        self.question.configure(
            text=symptom["name"]
        )

        self.choice.set("")

        if self.current == len(self.symptoms) - 1:
            self.next_button.configure(text="Selesai Diagnosis")
        else:
            self.next_button.configure(text="Selanjutnya")


    def next_question(self):

        if self.choice.get() == "":
            warning = ctk.CTkToplevel(self)
            warning.title("Peringatan")
            warning.geometry("320x150")

            ctk.CTkLabel(
                warning,
                text="Silakan pilih salah satu jawaban terlebih dahulu.",
                wraplength=260,
                justify="center"
            ).pack(pady=20)

            ctk.CTkButton(
                warning,
                text="OK",
                command=warning.destroy
            ).pack(pady=10)

            warning.grab_set()
            return

        code, symptom = self.symptoms[self.current]
        self.answers[code] = float(self.choice.get())

        self.current += 1

        if self.current >= len(self.symptoms):
            self.finish_callback(self.answers)
            return

        self.load_question()