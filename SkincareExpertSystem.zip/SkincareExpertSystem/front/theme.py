import customtkinter as ctk

# ======================================================
# Appearance
# ======================================================

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

# ======================================================
# Colors
# ======================================================

PRIMARY = "#2563EB"
PRIMARY_HOVER = "#1D4ED8"

BACKGROUND = "#F8FAFC"
CARD = "#FFFFFF"

TEXT = "#1F2937"
SUBTEXT = "#6B7280"

SUCCESS = "#22C55E"
WARNING = "#F59E0B"
DANGER = "#EF4444"

BORDER = "#E5E7EB"

# ======================================================
# Fonts
# ======================================================

TITLE_FONT = ("Segoe UI", 28, "bold")
HEADER_FONT = ("Segoe UI", 20, "bold")
SUBTITLE_FONT = ("Segoe UI", 15)
BODY_FONT = ("Segoe UI", 14)
BUTTON_FONT = ("Segoe UI", 14, "bold")

# ======================================================
# Window
# ======================================================

WINDOW_WIDTH = 950
WINDOW_HEIGHT = 650

CARD_RADIUS = 15