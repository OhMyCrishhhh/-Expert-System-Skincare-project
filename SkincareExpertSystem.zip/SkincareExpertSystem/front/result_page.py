import customtkinter as ctk

from front.theme import *
from back.knowledge import CONDITIONS
from back.recommendation import RECOMMENDATIONS


class ResultPage(ctk.CTkFrame):

    def __init__(self, parent, results, restart_callback):
        super().__init__(parent, fg_color=BACKGROUND)

        self.results = results
        self.restart_callback = restart_callback

        # ==========================
        # Ambil diagnosis terbaik
        # ==========================

        self.best_code = max(
            results,
            key=results.get
        )

        self.best_cf = results[self.best_code]

        self.recommendation = RECOMMENDATIONS[self.best_code]

        # ==========================
        # Judul
        # ==========================

        title = ctk.CTkLabel(
            self,
            text="🧴 HASIL DIAGNOSIS",
            font=TITLE_FONT,
            text_color=PRIMARY
        )

        title.pack(pady=(25, 10))

        # ==========================
        # Nama kondisi
        # ==========================

        condition = ctk.CTkLabel(
            self,
            text=CONDITIONS[self.best_code],
            font=("Segoe UI", 24, "bold")
        )

        condition.pack()

        # ==========================
        # Persentase
        # ==========================

        percent = ctk.CTkLabel(
            self,
            text=f"{self.best_cf*100:.2f} %",
            font=("Segoe UI", 38, "bold"),
            text_color="#22C55E"
        )

        percent.pack(pady=10)

        # ==========================
        # Progress Bar
        # ==========================

        progress = ctk.CTkProgressBar(
            self,
            width=500,
            height=18
        )

        progress.pack(pady=(5, 25))
        progress.set(self.best_cf)

        # ==========================
        # Card
        # ==========================

        card = ctk.CTkFrame(
            self,
            corner_radius=15
        )

        card.pack(
            padx=40,
            pady=10,
            fill="both",
            expand=True
        )

        # ==========================
        # Kandungan Aktif
        # ==========================

        ingredient_title = ctk.CTkLabel(
            card,
            text="✅ Kandungan Aktif yang Direkomendasikan",
            font=HEADER_FONT
        )

        ingredient_title.pack(
            anchor="w",
            padx=20,
            pady=(20, 10)
        )

        for item in self.recommendation["ingredients"]:

            lbl = ctk.CTkLabel(
                card,
                text="• " + item,
                font=BODY_FONT
            )

            lbl.pack(anchor="w", padx=40)
                    # ==========================
        # Yang Harus Dihindari
        # ==========================

        avoid_title = ctk.CTkLabel(
            card,
            text="❌ Yang Sebaiknya Dihindari",
            font=HEADER_FONT
        )

        avoid_title.pack(
            anchor="w",
            padx=20,
            pady=(20, 10)
        )

        for item in self.recommendation["avoid"]:

            lbl = ctk.CTkLabel(
                card,
                text="• " + item,
                font=BODY_FONT
            )

            lbl.pack(anchor="w", padx=40)

        # ==========================
        # Tips Perawatan
        # ==========================

        tips_title = ctk.CTkLabel(
            card,
            text="💡 Tips Perawatan",
            font=HEADER_FONT
        )

        tips_title.pack(
            anchor="w",
            padx=20,
            pady=(20, 10)
        )

        for item in self.recommendation["tips"]:

            lbl = ctk.CTkLabel(
                card,
                text="• " + item,
                font=BODY_FONT,
                wraplength=700,
                justify="left"
            )

            lbl.pack(
                anchor="w",
                padx=40,
                pady=2
            )

        # ==========================
        # Tombol
        # ==========================

        button = ctk.CTkButton(
            self,
            text="🔄 Diagnosis Lagi",
            width=220,
            height=45,
            font=BUTTON_FONT,
            command=self.restart_callback
        )

        button.pack(pady=25)