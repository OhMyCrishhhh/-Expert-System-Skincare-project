import customtkinter as ctk

from back.certainty_factor import diagnose

from front.theme import *
from front.welcome_page import WelcomePage
from front.diagnosis_page import DiagnosisPage
from front.result_page import ResultPage


class SkinExpertApp(ctk.CTk):

    def __init__(self):
        super().__init__()

        # ==========================
        # Window
        # ==========================
        self.title("SkinExpert")
        self.geometry("900x600")
        self.resizable(False, False)
        self.configure(fg_color=BACKGROUND)

        # ==========================
        # Container
        # ==========================
        self.container = ctk.CTkFrame(
            self,
            fg_color=BACKGROUND
        )

        self.container.pack(
            fill="both",
            expand=True
        )

        # Tampilkan halaman pertama
        self.show_welcome()

    # ======================================
    # Menghapus halaman yang sedang tampil
    # ======================================

    def clear_container(self):
        for widget in self.container.winfo_children():
            widget.destroy()

    # ======================================
    # Welcome Page
    # ======================================

    def show_welcome(self):

        self.clear_container()

        page = WelcomePage(
            self.container,
            self.show_diagnosis
        )

        page.pack(
            fill="both",
            expand=True
        )

    # ======================================
    # Diagnosis Page
    # ======================================

    def show_diagnosis(self):

        self.clear_container()

        page = DiagnosisPage(
            self.container,
            self.show_result      # callback saat diagnosis selesai
        )

        page.pack(
            fill="both",
            expand=True
        )

    # ======================================
    # Result Page
    # ======================================

    def show_result(self, answers):

        self.clear_container()

        # Hitung Certainty Factor
        results = diagnose(answers)

        # Tampilkan halaman hasil
        page = ResultPage(
            self.container,
            results,
            self.show_welcome
        )

        page.pack(
            fill="both",
            expand=True
        )