import customtkinter as ctk

from front.theme import *


class WelcomePage(ctk.CTkFrame):

    def __init__(self, parent, start_callback):
        super().__init__(parent, fg_color=BACKGROUND)

        self.start_callback = start_callback

        # ======================================
        # Container Tengah
        # ======================================

        container = ctk.CTkFrame(
            self,
            fg_color="transparent"
        )

        container.pack(
            expand=True
        )

        # ======================================
        # Logo
        # ======================================

        logo = ctk.CTkLabel(
            container,
            text="🧴",
            font=("Segoe UI Emoji", 60)
        )

        logo.pack(pady=(0, 10))

        # ======================================
        # Judul
        # ======================================

        title = ctk.CTkLabel(
            container,
            text="Skin Expert System",
            font=TITLE_FONT,
            text_color=PRIMARY
        )

        title.pack()

        # ======================================
        # Sub Judul
        # ======================================

        subtitle = ctk.CTkLabel(
            container,
            text="Sistem Pakar Rekomendasi Kandungan Aktif Skincare\nMenggunakan Metode Certainty Factor",
            font=HEADER_FONT,
            justify="center"
        )

        subtitle.pack(pady=(10, 20))

        # ======================================
        # Deskripsi
        # ======================================

        description = ctk.CTkLabel(
            container,
            text=(
                "Aplikasi ini membantu mengidentifikasi kondisi kulit\n"
                "berdasarkan gejala yang dipilih pengguna, kemudian\n"
                "merekomendasikan kandungan aktif skincare yang sesuai."
            ),
            font=BODY_FONT,
            justify="center",
            text_color=SUBTEXT
        )

        description.pack(pady=(0, 35))

        # ======================================
        # Tombol
        # ======================================

        start_button = ctk.CTkButton(
            container,
            text="Mulai Diagnosis",
            width=220,
            height=48,
            font=BUTTON_FONT,
            fg_color=PRIMARY,
            hover_color=PRIMARY_HOVER,
            command=self.start_callback
        )

        start_button.pack()

        # ======================================
        # Footer
        # ======================================

        footer = ctk.CTkLabel(
            self,
            text="© Skin Expert System | Certainty Factor",
            font=("Segoe UI", 11),
            text_color=SUBTEXT
        )

        footer.pack(
            side="bottom",
            pady=15
        )